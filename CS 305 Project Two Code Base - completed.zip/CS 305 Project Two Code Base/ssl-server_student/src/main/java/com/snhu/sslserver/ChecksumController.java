package com.snhu.sslserver;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api")
public class ChecksumController {

    @GetMapping("/checksum")
    public String getChecksum() {
        String data = "Hello World Check Sum!";
        String checksum = HashUtil.generateChecksum(data);
        return "Name: Alexander DeMarco\n" +
               "Unique Data: " + data + "\n" +
               "Checksum: " + checksum;
    }
}
